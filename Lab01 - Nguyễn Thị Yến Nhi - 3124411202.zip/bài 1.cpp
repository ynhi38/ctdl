#include <iostream>
#include <vector>
 using namespace std;
bool checkAlternatingSigns(const vector<double>& a) {
    for (size_t i = 1; i < a.size(); ++i) {
        if (a[i] * a[i - 1] >= 0) {
            return false;
        }
    }
    return true;
}
bool checkMonotonic(const vector<double>& a) {
    bool increasing = true;
    bool decreasing = true;
 
    for (size_t i = 1; i < a.size(); ++i) {
        if (a[i] > a[i - 1]) {
            decreasing = false;
        } else if (a[i] < a[i - 1]) {
            increasing = false;
        }
    }
    return increasing || decreasing;
}
bool checkSymmetry(const vector<double>& a) {
    size_t n = a.size();
    for (size_t i = 0; i < n / 2; ++i) {
        if (a[i] != a[n - 1 - i]) {
            return false; 
        }
    }
     return true;
}
 
int main() {
    int n;
    cout << "Nhap so phan tu n (n <= 100): ";
    cin >> n;
 
    if (n <= 0 || n > 100) {
        cout << "So phan tu khong hop le!" << endl;
        return 1;
    }
     vector<double> a(n);
    cout << "Nhap " << n << " phan tu: ";
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    bool isAlternating = checkAlternatingSigns(a);
    bool isMonotonic = checkMonotonic(a);
    bool isSymmetric = checkSymmetry(a);
    cout << "Tinh dan dau: " << (isAlternating ? "Co" : "Khong") << endl;
    cout << "Tinh don do: " << (isMonotonic ? "Co" : "Khong") << endl;
    cout << "Tinh chat doi xung: " << (isSymmetric ? "Co" : "Khong") << endl;
     return 0;
}
