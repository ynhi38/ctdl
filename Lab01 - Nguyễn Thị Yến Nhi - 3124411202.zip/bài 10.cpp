#include <iostream>
#include <string>

using namespace std;
void ChenKyTu(string &s, int k, char c) {
    s.insert(k, 1, c); 
}
int main() {
    string s;
    int k;
    char c;
    cout << "Nhap chuoi (toi da 1000 ky tu): ";
    getline(cin, s);
    if (s.length() > 1000) {
        cout << "Chuoi khong duoc qua 1000 ky tu!" << endl;
        return 1;
    }
    cout << "Nhap vi tri k (0 <= k <= " << s.length() << "): ";
    cin >> k;
    if (k < 0 || k > s.length()) {
        cout << "Vi tri k khong hop le!" << endl;
        return 1;
    }
    cout << "Nhap ky tu c: ";
    cin >> c;
    ChenKyTu(s, k, c);
    cout << "Chuoi sau khi chen ky tu '" << c << "' tai vi tri " << k << ": " << s << endl;
    return 0;
}
