#include <iostream>
#include <fstream>
#include <vector>
void DocCacSoNguyen(const std::string& filename) {
    std::ifstream infile(filename);
    if (!infile) {
        std::cerr << "Khong the mo file: " << filename << std::endl;
        return;
    }
    int n;
    infile >> n; // Đọc số lượng phần tử
    std::vector<int> arr(n); // Tạo mảng chứa n số nguyên
     for (int i = 0; i < n; ++i) {
        infile >> arr[i];
    }
    infile.close(); // Đóng file
    std::cout << "Cac so nguyen da doc duoc: ";
    for (int i = 0; i < n; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;
}
int main() {
    std::string filename = "DaySoNguyen.inp";
      DocCacSoNguyen(filename);
    return 0;
}
