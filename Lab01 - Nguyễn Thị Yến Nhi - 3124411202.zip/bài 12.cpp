#include <iostream>
#include <fstream>
#include <vector>
void DocMang2CSoNguyen(const std::string& filename) {
    std::ifstream infile(filename);
    if (!infile) {
        std::cerr << "Khong the mo file: " << filename << std::endl;
        return;
    }
    int n, m;
    infile >> n >> m; 
    std::vector<std::vector<int>> arr(n, std::vector<int>(m));
        for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            infile >> arr[i][j];
        }
    }
    infile.close(); // Đóng file
    std::cout << "Mang 2 chieu da doc duoc:" << std::endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            std::cout << arr[i][j] << " ";
        }
        std::cout << std::endl; 
    }
}
int main() {
    std::string filename = "MangSo.inp";
    DocMang2CSoNguyen(filename);
    return 0;
}
