#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
bool isPrime(int num) {
    if (num <= 1) return false;
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) return false; 
    }
    return true;
}
void TimSoNguyenTo(const std::string& inputFile, const std::string& outputFile) {
    std::ifstream infile(inputFile);
    if (!infile) {
        std::cerr << "Khong the mo file: " << inputFile << std::endl;
        return;
    }
    int n;
    infile >> n; 
    std::vector<int> primes; 
    for (int i = 0; i < n; ++i) {
        int a;
        infile >> a;
        if (isPrime(a)) {
            primes.push_back(a);
        }
    }

    infile.close(); 
    std::sort(primes.begin(), primes.end());
    std::ofstream outfile(outputFile);
    if (!outfile) {
        std::cerr << "Khong the mo file: " << outputFile << std::endl;
return;
    }
    outfile << primes.size() << std::endl;
    for (size_t i = 0; i < primes.size(); ++i) {
        outfile << primes[i];
        if (i < primes.size() - 1) {
            outfile << " "; 
        }
    }
    outfile << std::endl;
    outfile.close(); // Đóng file
}
int main() {
    std::string inputFile = "NT.INP";
    std::string outputFile = "NT.OUT";
    TimSoNguyenTo(inputFile, outputFile);
    return 0;
}
