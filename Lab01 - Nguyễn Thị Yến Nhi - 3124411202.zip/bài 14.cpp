#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
using namespace std;
int main() {
    ifstream input("CapSo.INP");
    ofstream output("CapSo.OUT");
    int n, k;
    input >> n >> k;

    vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        input >> a[i];
    }
    vector<pair<int, int>> pairs;
    unordered_map<int, int> num_map;
    for (int i = 0; i < n; ++i) {
        int complement = k - a[i];
        if (num_map.find(complement) != num_map.end()) {
            for (int j = 0; j < num_map[complement]; ++j) {
                pairs.push_back({complement, a[i]});
            }
        }
        num_map[a[i]]++;
    }
    if (pairs.empty()) {
        output << 0;
    } else {
        for (const auto& p : pairs) {
            output << p.first << " " << p.second << endl;
        }
    }
    input.close();
    output.close();
    return 0;
}
