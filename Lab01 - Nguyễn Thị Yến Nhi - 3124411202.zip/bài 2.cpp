#include <iostream>
#include <vector> 
using namespace std;

bool isPrime(int num) {
    if (num <= 1) return false;
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) return false;
    }
    return true;
} 
int main() {
    int n;
    cout << "Nhap so phan tu n (n <= 100): ";
    cin >> n;
    if (n <= 0 || n > 100) {
        cout << "So phan tu khong hop le!" << endl;
        return 1;
    }
    vector<int> a(n);
    cout << "Nhap " << n << " phan tu: ";
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
 
    vector<int> b;
 
    for (int i = 0; i < n; ++i) {
        if (isPrime(a[i])) {
            b.push_back(a[i]);
        }
    }
    cout << "Cac so nguyen to trong day a: ";
    if (b.empty()) {
        cout << "Khong co so nguyen to nao." << endl;
    } else {
        for (size_t i = 0; i < b.size(); ++i) {
            cout << b[i] << " ";
        }
        cout << endl;
    }
    return 0;
}
