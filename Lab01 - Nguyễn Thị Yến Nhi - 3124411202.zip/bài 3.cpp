#include <iostream>
#include <cmath>
using namespace std;
void solveQuadratic(double a, double b, double c) {
    double* x1 = new double;
    double* x2 = new double;
    if (a == 0) {
        if (b == 0) {
            if (c == 0) {
                cout << "Phuong trinh co vo so nghiem." << endl;
            } else {
                cout << "Phuong trinh vo nghiem." << endl;
            }
        } else {
            *x1 = -c / b;
            cout << "Phuong trinh co 1 nghiem: x = " << *x1 << endl;
        }
    } else {
        double delta = b * b - 4 * a * c;
        if (delta > 0) {
            *x1 = (-b + sqrt(delta)) / (2 * a);
            *x2 = (-b - sqrt(delta)) / (2 * a);
            cout << "Phuong trinh co 2 nghiem phan biet: x1 = " << *x1 << ", x2 = " << *x2 << endl;
        } else if (delta == 0) {
            *x1 = -b / (2 * a);
            cout << "Phuong trinh co 1 nghiem kep: x = " << *x1 << endl;
        } else {
            cout << "Phuong trinh vo nghiem." << endl;
        }
    }

    delete x1;
    delete x2;
}
int main() {
    double a, b, c;
    cout << "Nhap he so a: ";
    cin >> a;
    cout << "Nhap he so b: ";
    cin >> b;
    cout << "Nhap he so c: ";
    cin >> c;
    solveQuadratic(a, b, c);
    return 0;
}
