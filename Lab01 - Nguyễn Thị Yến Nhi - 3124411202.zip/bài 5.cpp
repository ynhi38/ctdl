#include <iostream>
using namespace std;
int main() {
    char arr[100], b[100];
    int n, j = 0;
    cout << "Nhap so luong ky tu (n <= 100): ";
    cin >> n;
    cout << "Nhap day ky tu: ";
     cin >> arr;
    for (int i = 0; i < n; i++) {
        if (arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u' ||
            arr[i] == 'A' || arr[i] == 'E' || arr[i] == 'I' || arr[i] == 'O' || arr[i] == 'U') {
            b[j++] = arr[i];
        }
    }
    b[j] = '\0'; // Kết thúc chuỗi b
    cout << "Day ky tu nguyen am: " << b << endl;
    return 0;
}
