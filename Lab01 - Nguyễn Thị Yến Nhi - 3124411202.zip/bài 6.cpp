#include <iostream>
#include <vector>
void mergeSortedArrays(const std::vector<int>& a, const std::vector<int>& b, std::vector<int>& c) {
    int n = a.size();
    int m = b.size();
    int i = 0, j = 0;
    // Hợp nhất hai dãy a và b vào dãy c
    while (i < n && j < m) {
        if (a[i] < b[j]) {
            c.push_back(a[i]);
            i++;
        } else {
            c.push_back(b[j]);
            j++;
        }
    }
        while (i < n) {
        c.push_back(a[i]);
        i++;
    }
    while (j < m) {
        c.push_back(b[j]);
        j++;
    }
}
int main() {
    int n, m;
    std::cout << "Nhap so phan tu cua day a: ";
    std::cin >> n;
      std::vector<int> a(n);
    std::cout << "Nhap cac phan tu cua day a (tang dan): ";
    for (int i = 0; i < n; i++) {
        std::cin >> a[i];
    }
    std::cout << "Nhap so phan tu cua day b: ";
    std::cin >> m;
    std::vector<int> b(m);
    
    // Nhập các phần tử của dãy b
    std::cout << "Nhap cac phan tu cua day b (tang dan): ";
    for (int i = 0; i < m; i++) {
        std::cin >> b[i];
    }
    std::vector<int> c;
    mergeSortedArrays(a, b, c);
    std::cout << "Day c sau khi hop nhat: ";
    for (int i = 0; i < c.size(); i++) {
        std::cout << c[i] << " ";
    }
    std::cout << std::endl;
    return 0;
}
