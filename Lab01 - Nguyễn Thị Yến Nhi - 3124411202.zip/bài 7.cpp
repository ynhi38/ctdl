#include <iostream>
#include <vector>
int main() {
    int n;
     std::cout << "Nhap so phan tu cua day a: ";
    std::cin >> n;
    std::vector<int> a(n);
    std::vector<int> b; 
    std::vector<int> c; 
    std::cout << "Nhap cac phan tu cua day a: ";
    for (int i = 0; i < n; i++) {
        std::cin >> a[i];
    }
        for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0) {
            b.push_back(a[i]); 
        } else {
            c.push_back(a[i]); 
        }
    }
    std::cout << "Day b (so chan): ";
    for (int i = 0; i < b.size(); i++) {
        std::cout << b[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "Day c (so le): ";
    for (int i = 0; i < c.size(); i++) {
        std::cout << c[i] << " ";
    }
    std::cout << std::endl;
    return 0;
}
