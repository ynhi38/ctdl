#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int main() {
    string s;
    cout << "Nhap chuoi (toi da 1000 ky tu): ";
    getline(cin, s);
        if (s.length() > 1000) {
        cout << "Chuoi khong duoc qua 1000 ky tu!" << endl;
        return 1;
    }
    sort(s.begin(), s.end());
    cout << "Chuoi sau khi sap xep: " << s << endl;
    return 0;
}
