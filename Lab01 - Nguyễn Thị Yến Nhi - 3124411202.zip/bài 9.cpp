#include <iostream>
#include <string>
using namespace std;
int main() {
    string s;
    int k;
    cout << "Nhap chuoi (toi da 1000 ky tu): ";
    getline(cin, s);
    if (s.length() > 1000) {
        cout << "Chuoi khong duoc qua 1000 ky tu!" << endl;
        return 1;
    }
    cout << "Nhap vi tri k (bat dau tu 0): ";
    cin >> k;
    if (k < 0 || k >= s.length()) {
        cout << "Vi tri k khong hop le!" << endl;
        return 1;
    }
    s.erase(k, 1);
    cout << "Chuoi sau khi xoa ky tu tai vi tri " << k << ": " << s << endl;
    return 0;
}
