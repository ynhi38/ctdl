#include <iostream>
#include <cstring>
using namespace std;

class SinhVien {
public:
    char hoTen[50];
    char diaChi[70];
    char lop[10];
    int khoa;

    void nhap() {
        cout << "Nhap ho ten: ";
        cin.ignore();
        cin.getline(hoTen, 50);
        
        cout << "Nhap dia chi: ";
        cin.getline(diaChi, 70);
        
        cout << "Nhap lop: ";
        cin.getline(lop, 10);
        
        cout << "Nhap khoa: ";
        cin >> khoa;
    }

    void xuat() const {
        cout << "Ho ten: " << hoTen << endl;
        cout << "Dia chi: " << diaChi << endl;
        cout << "Lop: " << lop << endl;
        cout << "Khoa: " << khoa << endl;
    }

    bool soSanhTheoTen(const SinhVien& sv) const {
        return strcmp(hoTen, sv.hoTen) < 0;
    }
    
    bool soSanhTheoDiaChi(const SinhVien& sv) const {
        return strcmp(diaChi, sv.diaChi) < 0;
    }
    
    bool soSanhTheoLop(const SinhVien& sv) const {
        return strcmp(lop, sv.lop) < 0;
    }
    
    bool soSanhTheoKhoa(const SinhVien& sv) const {
        return khoa < sv.khoa;
    }
};

int main() {
    const int n = 2; // Số lượng sinh viên
    SinhVien danhSach[n];
    
    for (int i = 0; i < n; i++) {
        cout << "\nNhap thong tin sinh vien " << i + 1 << ":\n";
        danhSach[i].nhap();
    }
    
    cout << "\nDanh sach sinh vien:\n";
    for (int i = 0; i < n; i++) {
        danhSach[i].xuat();
        cout << endl;
    }
    
    cout << "\nSo sanh sinh vien 1 va sinh vien 2:\n";
    cout << "Theo ten: " << (danhSach[0].soSanhTheoTen(danhSach[1]) ? "SV1 < SV2" : "SV2 <= SV1") << endl;
    cout << "Theo dia chi: " << (danhSach[0].soSanhTheoDiaChi(danhSach[1]) ? "SV1 < SV2" : "SV2 <= SV1") << endl;
    cout << "Theo lop: " << (danhSach[0].soSanhTheoLop(danhSach[1]) ? "SV1 < SV2" : "SV2 <= SV1") << endl;
    cout << "Theo khoa: " << (danhSach[0].soSanhTheoKhoa(danhSach[1]) ? "SV1 < SV2" : "SV2 <= SV1") << endl;
    
    return 0;
}
