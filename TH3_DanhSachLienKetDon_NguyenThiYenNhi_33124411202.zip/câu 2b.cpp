#include <iostream>
#include <cstring>
using namespace std;

class SinhVien {
public:
    char hoTen[50];
    char diaChi[70];
    char lop[10];
    int khoa;

    void nhap() {
        cout << "Nhap ho ten: ";
        cin.ignore();
        cin.getline(hoTen, 50);
        
        cout << "Nhap dia chi: ";
        cin.getline(diaChi, 70);
        
        cout << "Nhap lop: ";
        cin.getline(lop, 10);
        
        cout << "Nhap khoa: ";
        cin >> khoa;
    }

    void xuat() const {
        cout << "Ho ten: " << hoTen << endl;
        cout << "Dia chi: " << diaChi << endl;
        cout << "Lop: " << lop << endl;
        cout << "Khoa: " << khoa << endl;
    }

    static bool soSanhTheoTen(const SinhVien& a, const SinhVien& b) {
        return strcmp(a.hoTen, b.hoTen) < 0;
    }
    
    static bool soSanhTheoKhoa(const SinhVien& a, const SinhVien& b) {
        return a.khoa < b.khoa;
    }
};

class ListSV {
private:
    SinhVien* arr;
    int size;
    int capacity;

    void resize() {
        capacity *= 2;
        SinhVien* newArr = new SinhVien[capacity];
        for (int i = 0; i < size; i++) {
            newArr[i] = arr[i];
        }
        delete[] arr;
        arr = newArr;
    }

public:
    ListSV(int cap = 10) : size(0), capacity(cap) {
        arr = new SinhVien[capacity];
    }

    ~ListSV() {
        delete[] arr;
    }

    void add(const SinhVien& sv) {
        if (size == capacity) resize();
        arr[size++] = sv;
    }

    void remove(int index) {
        if (index < 0 || index >= size) return;
        for (int i = index; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        size--;
    }

    void addList(const SinhVien* list, int n) {
        for (int i = 0; i < n; i++) {
            add(list[i]);
        }
    }

    void print() const {
        for (int i = 0; i < size; i++) {
            arr[i].xuat();
            cout << "------------------" << endl;
        }
    }

    void selectionSort(bool (*cmp)(const SinhVien&, const SinhVien&)) {
        for (int i = 0; i < size - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < size; j++) {
                if (cmp(arr[j], arr[minIndex])) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                swap(arr[i], arr[minIndex]);
            }
        }
    }
};

int main() {
    ListSV danhSach;
    int n;
    cout << "Nhap so luong sinh vien: ";
    cin >> n;
    
    for (int i = 0; i < n; i++) {
        cout << "\nNhap thong tin sinh vien " << i + 1 << ":\n";
        SinhVien sv;
        sv.nhap();
        danhSach.add(sv);
    }
    
    cout << "\nDanh sach sinh vien truoc khi sap xep:\n";
    danhSach.print();
    
    danhSach.selectionSort(SinhVien::soSanhTheoTen);
    cout << "\nDanh sach sinh vien sau khi sap xep theo ten:\n";
    danhSach.print();
    
    danhSach.selectionSort(SinhVien::soSanhTheoKhoa);
    cout << "\nDanh sach sinh vien sau khi sap xep theo khoa:\n";
    danhSach.print();
    
    return 0;
}