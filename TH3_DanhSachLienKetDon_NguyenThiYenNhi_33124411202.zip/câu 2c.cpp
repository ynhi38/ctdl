#include <iostream>
#include <cstring>
using namespace std;

class SinhVien {
public:
    char hoTen[50];
    char diaChi[70];
    char lop[10];
    int khoa;

    void nhap() {
        cout << "Nhap ho ten: ";
        cin.ignore();
        cin.getline(hoTen, 50);
        
        cout << "Nhap dia chi: ";
        cin.getline(diaChi, 70);
        
        cout << "Nhap lop: ";
        cin.getline(lop, 10);
        
        cout << "Nhap khoa: ";
        cin >> khoa;
    }

    void xuat() const {
        cout << "Ho ten: " << hoTen << endl;
        cout << "Dia chi: " << diaChi << endl;
        cout << "Lop: " << lop << endl;
        cout << "Khoa: " << khoa << endl;
    }
};

class ListSV {
private:
    SinhVien* arr;
    int size;
    int capacity;

    void resize() {
        capacity *= 2;
        SinhVien* newArr = new SinhVien[capacity];
        for (int i = 0; i < size; i++) {
            newArr[i] = arr[i];
        }
        delete[] arr;
        arr = newArr;
    }

public:
    ListSV(int cap = 10) : size(0), capacity(cap) {
        arr = new SinhVien[capacity];
    }

    ~ListSV() {
        delete[] arr;
    }

    void add(const SinhVien& sv) {
        if (size == capacity) resize();
        arr[size++] = sv;
    }

    void removeByName(const char* name) {
        for (int i = 0; i < size; i++) {
            if (strcmp(arr[i].hoTen, name) == 0) {
                remove(i);
                break;
            }
        }
    }

    void removeByAddress(const char* address) {
        for (int i = 0; i < size; i++) {
            if (strcmp(arr[i].diaChi, address) == 0) {
                remove(i);
                break;
            }
        }
    }

    void remove(int index) {
        if (index < 0 || index >= size) return;
        for (int i = index; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        size--;
    }

    void print() const {
        for (int i = 0; i < size; i++) {
            arr[i].xuat();
            cout << "------------------" << endl;
        }
    }
};

int main() {
    ListSV danhSach;
    
    cout << "Nhap danh sach 10 sinh vien:\n";
    for (int i = 0; i < 10; i++) {
        SinhVien sv;
        sv.nhap();
        danhSach.add(sv);
    }
    
    cout << "\nDanh sach sinh vien:\n";
    danhSach.print();
    
    danhSach.removeByName("Nguyen Van Teo");
    danhSach.removeByAddress("Nguyen Van Cu");
    
    SinhVien newSV;
    strcpy(newSV.hoTen, "Tran Thi Mo");
    strcpy(newSV.diaChi, "25 Hong Bang");
    strcpy(newSV.lop, "TT0901");
    newSV.khoa = 2009;
    danhSach.add(newSV);
    
    cout << "\nDanh sach sau khi chinh sua:\n";
    danhSach.print();
    
    return 0;
}